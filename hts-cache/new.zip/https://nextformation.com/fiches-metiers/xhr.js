<!doctype html>
<html lang="fr-FR">

<head>

    <meta http-equiv="content-type" content="text/html;charset=UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0" />

    <title>Oups Erreur 404 &#8211; Nextformation</title>
<link href='https://fonts.gstatic.com' crossorigin rel='preconnect' />
<style id='global-styles-inline-css' type='text/css'>
body{--wp--preset--color--black: #000000;--wp--preset--color--cyan-bluish-gray: #abb8c3;--wp--preset--color--white: #ffffff;--wp--preset--color--pale-pink: #f78da7;--wp--preset--color--vivid-red: #cf2e2e;--wp--preset--color--luminous-vivid-orange: #ff6900;--wp--preset--color--luminous-vivid-amber: #fcb900;--wp--preset--color--light-green-cyan: #7bdcb5;--wp--preset--color--vivid-green-cyan: #00d084;--wp--preset--color--pale-cyan-blue: #8ed1fc;--wp--preset--color--vivid-cyan-blue: #0693e3;--wp--preset--color--vivid-purple: #9b51e0;--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple: linear-gradient(135deg,rgba(6,147,227,1) 0%,rgb(155,81,224) 100%);--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan: linear-gradient(135deg,rgb(122,220,180) 0%,rgb(0,208,130) 100%);--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange: linear-gradient(135deg,rgba(252,185,0,1) 0%,rgba(255,105,0,1) 100%);--wp--preset--gradient--luminous-vivid-orange-to-vivid-red: linear-gradient(135deg,rgba(255,105,0,1) 0%,rgb(207,46,46) 100%);--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray: linear-gradient(135deg,rgb(238,238,238) 0%,rgb(169,184,195) 100%);--wp--preset--gradient--cool-to-warm-spectrum: linear-gradient(135deg,rgb(74,234,220) 0%,rgb(151,120,209) 20%,rgb(207,42,186) 40%,rgb(238,44,130) 60%,rgb(251,105,98) 80%,rgb(254,248,76) 100%);--wp--preset--gradient--blush-light-purple: linear-gradient(135deg,rgb(255,206,236) 0%,rgb(152,150,240) 100%);--wp--preset--gradient--blush-bordeaux: linear-gradient(135deg,rgb(254,205,165) 0%,rgb(254,45,45) 50%,rgb(107,0,62) 100%);--wp--preset--gradient--luminous-dusk: linear-gradient(135deg,rgb(255,203,112) 0%,rgb(199,81,192) 50%,rgb(65,88,208) 100%);--wp--preset--gradient--pale-ocean: linear-gradient(135deg,rgb(255,245,203) 0%,rgb(182,227,212) 50%,rgb(51,167,181) 100%);--wp--preset--gradient--electric-grass: linear-gradient(135deg,rgb(202,248,128) 0%,rgb(113,206,126) 100%);--wp--preset--gradient--midnight: linear-gradient(135deg,rgb(2,3,129) 0%,rgb(40,116,252) 100%);--wp--preset--duotone--dark-grayscale: url('#wp-duotone-dark-grayscale');--wp--preset--duotone--grayscale: url('#wp-duotone-grayscale');--wp--preset--duotone--purple-yellow: url('#wp-duotone-purple-yellow');--wp--preset--duotone--blue-red: url('#wp-duotone-blue-red');--wp--preset--duotone--midnight: url('#wp-duotone-midnight');--wp--preset--duotone--magenta-yellow: url('#wp-duotone-magenta-yellow');--wp--preset--duotone--purple-green: url('#wp-duotone-purple-green');--wp--preset--duotone--blue-orange: url('#wp-duotone-blue-orange');--wp--preset--font-size--small: 13px;--wp--preset--font-size--medium: 20px;--wp--preset--font-size--large: 36px;--wp--preset--font-size--x-large: 42px;}.has-black-color{color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-color{color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-color{color: var(--wp--preset--color--white) !important;}.has-pale-pink-color{color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-color{color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-color{color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-color{color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-color{color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-color{color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-color{color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-color{color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-color{color: var(--wp--preset--color--vivid-purple) !important;}.has-black-background-color{background-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-background-color{background-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-background-color{background-color: var(--wp--preset--color--white) !important;}.has-pale-pink-background-color{background-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-background-color{background-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-background-color{background-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-background-color{background-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-background-color{background-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-background-color{background-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-background-color{background-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-background-color{background-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-background-color{background-color: var(--wp--preset--color--vivid-purple) !important;}.has-black-border-color{border-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-border-color{border-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-border-color{border-color: var(--wp--preset--color--white) !important;}.has-pale-pink-border-color{border-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-border-color{border-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-border-color{border-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-border-color{border-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-border-color{border-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-border-color{border-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-border-color{border-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-border-color{border-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-border-color{border-color: var(--wp--preset--color--vivid-purple) !important;}.has-vivid-cyan-blue-to-vivid-purple-gradient-background{background: var(--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple) !important;}.has-light-green-cyan-to-vivid-green-cyan-gradient-background{background: var(--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan) !important;}.has-luminous-vivid-amber-to-luminous-vivid-orange-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange) !important;}.has-luminous-vivid-orange-to-vivid-red-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-orange-to-vivid-red) !important;}.has-very-light-gray-to-cyan-bluish-gray-gradient-background{background: var(--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray) !important;}.has-cool-to-warm-spectrum-gradient-background{background: var(--wp--preset--gradient--cool-to-warm-spectrum) !important;}.has-blush-light-purple-gradient-background{background: var(--wp--preset--gradient--blush-light-purple) !important;}.has-blush-bordeaux-gradient-background{background: var(--wp--preset--gradient--blush-bordeaux) !important;}.has-luminous-dusk-gradient-background{background: var(--wp--preset--gradient--luminous-dusk) !important;}.has-pale-ocean-gradient-background{background: var(--wp--preset--gradient--pale-ocean) !important;}.has-electric-grass-gradient-background{background: var(--wp--preset--gradient--electric-grass) !important;}.has-midnight-gradient-background{background: var(--wp--preset--gradient--midnight) !important;}.has-small-font-size{font-size: var(--wp--preset--font-size--small) !important;}.has-medium-font-size{font-size: var(--wp--preset--font-size--medium) !important;}.has-large-font-size{font-size: var(--wp--preset--font-size--large) !important;}.has-x-large-font-size{font-size: var(--wp--preset--font-size--x-large) !important;}
</style>
<link rel='stylesheet' id='nextformation-css'  href='https://nextformation.com/app/themes/nextformation/dist/styles/main_f7423051.css' type='text/css' media='all' />
<style id='rocket-lazyload-inline-css' type='text/css'>
.rll-youtube-player{position:relative;padding-bottom:56.23%;height:0;overflow:hidden;max-width:100%;}.rll-youtube-player:focus-within{outline: 2px solid currentColor;outline-offset: 5px;}.rll-youtube-player iframe{position:absolute;top:0;left:0;width:100%;height:100%;z-index:100;background:0 0}.rll-youtube-player img{bottom:0;display:block;left:0;margin:auto;max-width:100%;width:100%;position:absolute;right:0;top:0;border:none;height:auto;-webkit-transition:.4s all;-moz-transition:.4s all;transition:.4s all}.rll-youtube-player img:hover{-webkit-filter:brightness(75%)}.rll-youtube-player .play{height:100%;width:100%;left:0;top:0;position:absolute;background:url(https://nextformation.com/app/plugins/wp-rocket/assets/img/youtube.png) no-repeat center;background-color: transparent !important;cursor:pointer;border:none;}
</style>
    <meta name="description" content="" />
    <meta name="keywords" content="" />
    <meta name="google-site-verification" content="qvqH3cAr2pA3vT14quYiDzXtA3oI3Lx-ZmjWc3Lmqd4" />
    <meta name="msvalidate.01" content="9BC602224D0A850290A3A3DF417DCCBA" />
    <meta property="og:type" content="website" />
    <meta property="og:url" content="https://nextformation.com/fiches-metiers/xhr.js" />
    <meta property="og:title" content="Oups Erreur 404 &ndash; Nextformation" />
    <meta property="twitter:title" content="Oups Erreur 404 &ndash; Nextformation" />
    <script>window.grc_key = '6LcTE7IUAAAAAEU7XjsiHU6-cvp1qhFvy4OrXb3I';</script>
    <script id="js-grecaptcha" src="https://www.google.com/recaptcha/api.js?render=explicit" async defer></script>
    <link rel="canonical" href="https://nextformation.com/fiches-metiers/xhr.js" />
<link rel="icon" href="https://nextformation.com/app/uploads/2021/03/favicon.png" sizes="32x32" />
<link rel="icon" href="https://nextformation.com/app/uploads/2021/03/favicon.png" sizes="192x192" />
<link rel="apple-touch-icon" href="https://nextformation.com/app/uploads/2021/03/favicon.png" />
<meta name="msapplication-TileImage" content="https://nextformation.com/app/uploads/2021/03/favicon.png" />
    <!-- TrustBox script -->
    <script type="text/javascript" src="//widget.trustpilot.com/bootstrap/v5/tp.widget.bootstrap.min.js" async></script>
    <!-- End TrustBox script -->
<noscript><style id="rocket-lazyload-nojs-css">.rll-youtube-player, [data-lazy-src]{display:none !important;}</style></noscript>    
    
</head>

<body class="article">

    <div class="main-layout">

        <div id="page-navs">
            <div class="page-navs-ct">

                <div class="nav-statics order-xl-2">

                    
                    <div class="menu-brand">
                        <a class="menu-brand-logo" href="https://nextformation.com" target="_top">
                            <span class="sr-only">Nextformation</span>
                            <img data-src="https://nextformation.com/app/themes/nextformation/dist/images/common/nextformation_logo_38470f5e.png" alt="Nextformation" />
                        </a>
                    </div>

                    
                    <div class="menu-mobile-icons">
                        <div class="btn page-search-cta d-md-none">
                            <select class="btn form-control search-select">
                                <option selected disabled>Rechercher une formation</option>
                            </select>
                            <span class="btn search-icon"><i class="fas fa-search text-primary"></i></span>
                        </div>
                        <div class="menu-toggle-burger">
                            <a class="btn burger-menu"></a>
                            <a class="btn btn-close menu-hide"></a>
                        </div>
                    </div>

                </div>

                
                <div id="menu-primary" class="menu-hide order-xl-3">
                    <div class="container justify-content-end">
                        
                        <ul class="nav nav-items">
                                                        <li class="nav-item submenu-hide maxi-menu">
                                                                <a class="nav-link">
                                                                    <span>Formations métiers</span>
                                                                        <span class="nav-link-icon fa"></span>
                                                                    </a>
                                                                <div class="mm-container-fluid"><div class="mm-container">

                                    

                                    <ul class="nav nav-items">
                                        <li class="nav-item">
                                            <a class="nav-link-parent">
                                                <span class="nav-link-icon fa"></span> <span>Formations métiers</span>
                                            </a>
                                        </li>
                                                                                <li class="nav-item submenu-hide">
                                            <a href="https://nextformation.com/formations-metiers/formations-comptabilite-gestion" class="nav-link">
                                                <span>Formations Comptabilité & Gestion</span>
                                                                                                <span class="nav-link-icon fa"></span>
                                                                                            </a>
                                                                                        <ul class="nav nav-items">
                                                <li class="nav-item nav-item-static">
                                                    <a class="nav-link-parent">
                                                        <span class="nav-link-icon fa"></span> <span>Formations Comptabilité & Gestion</span>
                                                    </a>
                                                </li>
                                                                                                                                                <li class="nav-item nav-border-bottom">
                                                                                                        <p class="nav-section-label mb-0">Bac</p>
                                                                                                            <ul class="nav nav-items">
                                                                                                                    <li class="nav-item">
                                                            <a href="https://nextformation.com/formations-metiers/formations-comptabilite-gestion/assistant-comptable" class="nav-link">
                                                                Formation Comptable Assistant(e) 
                                                            </a>
                                                        </li>
                                                                                                                </ul>
                                                                                                                                                            </li>
                                                                                                                                                <li class="nav-item">
                                                                                                        <p class="nav-section-label mb-0">Bac +2</p>
                                                                                                            <ul class="nav nav-items">
                                                                                                                    <li class="nav-item">
                                                            <a href="https://nextformation.com/formations-metiers/formations-comptabilite-gestion/formation-gestionnaire-comptable-et-fiscal" class="nav-link">
                                                                Formation Gestionnaire comptable et fiscal
                                                            </a>
                                                        </li>
                                                                                                                </ul>
                                                                                                                                                            </li>
                                                                                                <li class="nav-item nav-item-static nav-item-cta">
                                                    <a href="https://nextformation.com/formations-metiers/formations-comptabilite-gestion" class="btn btn-secondary">Visiter la page de la filière</a>
                                                </li>
                                            </ul>
                                                                                    </li>
                                                                                <li class="nav-item submenu-hide">
                                            <a href="https://nextformation.com/formations-metiers/formations-informatique-developpement-reseaux" class="nav-link">
                                                <span>Formations Informatique, Développement & Réseaux</span>
                                                                                                <span class="nav-link-icon fa"></span>
                                                                                            </a>
                                                                                        <ul class="nav nav-items">
                                                <li class="nav-item nav-item-static">
                                                    <a class="nav-link-parent">
                                                        <span class="nav-link-icon fa"></span> <span>Formations Informatique, Développement & Réseaux</span>
                                                    </a>
                                                </li>
                                                                                                                                                <li class="nav-item nav-border-bottom">
                                                                                                        <p class="nav-section-label mb-0">Bac</p>
                                                                                                            <ul class="nav nav-items">
                                                                                                                    <li class="nav-item">
                                                            <a href="https://nextformation.com/formations-metiers/formations-informatique-developpement-reseaux/formation-de-technicienne-dassistance-informatique" class="nav-link">
                                                                Formation de Technicien(ne) d’Assistance Informatique
                                                            </a>
                                                        </li>
                                                                                                                </ul>
                                                                                                                                                            </li>
                                                                                                                                                <li class="nav-item nav-border-bottom">
                                                                                                        <p class="nav-section-label mb-0">Bac +2</p>
                                                                                                            <ul class="nav nav-items">
                                                                                                                    <li class="nav-item">
                                                            <a href="https://nextformation.com/formations-metiers/formations-informatique-developpement-reseaux/formation-de-developpeur-web" class="nav-link">
                                                                Formation Développeur Web
                                                            </a>
                                                        </li>
                                                                                                                    <li class="nav-item">
                                                            <a href="https://nextformation.com/formations-metiers/formations-informatique-developpement-reseaux/formation-technicien-systemes-et-reseaux" class="nav-link">
                                                                Formation Technicien(ne) Systèmes et Réseaux
                                                            </a>
                                                        </li>
                                                                                                                </ul>
                                                                                                                                                            </li>
                                                                                                                                                <li class="nav-item">
                                                                                                        <p class="nav-section-label mb-0">Bac +3</p>
                                                                                                            <ul class="nav nav-items">
                                                                                                                    <li class="nav-item">
                                                            <a href="https://nextformation.com/formations-metiers/formations-informatique-developpement-reseaux/formation-administrateur-systemes-et-reseaux" class="nav-link">
                                                                Formation Administrateur(trice) Systèmes et Réseaux
                                                            </a>
                                                        </li>
                                                                                                                </ul>
                                                                                                                                                            </li>
                                                                                                <li class="nav-item nav-item-static nav-item-cta">
                                                    <a href="https://nextformation.com/formations-metiers/formations-informatique-developpement-reseaux" class="btn btn-secondary">Visiter la page de la filière</a>
                                                </li>
                                            </ul>
                                                                                    </li>
                                                                                <li class="nav-item submenu-hide">
                                            <a href="https://nextformation.com/formations-metiers/formations-marketing-communication-design" class="nav-link">
                                                <span>Formations Marketing, Communication & Design</span>
                                                                                                <span class="nav-link-icon fa"></span>
                                                                                            </a>
                                                                                        <ul class="nav nav-items">
                                                <li class="nav-item nav-item-static">
                                                    <a class="nav-link-parent">
                                                        <span class="nav-link-icon fa"></span> <span>Formations Marketing, Communication & Design</span>
                                                    </a>
                                                </li>
                                                                                                                                                <li class="nav-item nav-border-bottom">
                                                                                                        <p class="nav-section-label mb-0">Bac</p>
                                                                                                            <ul class="nav nav-items">
                                                                                                                    <li class="nav-item">
                                                            <a href="https://nextformation.com/formations-metiers/formations-marketing-communication-design/formation-infographiste" class="nav-link">
                                                                Formation Infographiste
                                                            </a>
                                                        </li>
                                                                                                                </ul>
                                                                                                                                                            </li>
                                                                                                                                                <li class="nav-item nav-border-bottom">
                                                                                                        <p class="nav-section-label mb-0">Bac +2</p>
                                                                                                            <ul class="nav nav-items">
                                                                                                                    <li class="nav-item">
                                                            <a href="https://nextformation.com/formations-metiers/formations-marketing-communication-design/formation-web-designer" class="nav-link">
                                                                Formation Web designer
                                                            </a>
                                                        </li>
                                                                                                                </ul>
                                                                                                                                                            </li>
                                                                                                                                                <li class="nav-item">
                                                                                                        <p class="nav-section-label mb-0">Bac +3</p>
                                                                                                            <ul class="nav nav-items">
                                                                                                                    <li class="nav-item">
                                                            <a href="https://nextformation.com/formations-metiers/formations-marketing-communication-design/formation-concepteur-designer-ui" class="nav-link">
                                                                Formation UX Designer
                                                            </a>
                                                        </li>
                                                                                                                </ul>
                                                                                                                                                            </li>
                                                                                                <li class="nav-item nav-item-static nav-item-cta">
                                                    <a href="https://nextformation.com/formations-metiers/formations-marketing-communication-design" class="btn btn-secondary">Visiter la page de la filière</a>
                                                </li>
                                            </ul>
                                                                                    </li>
                                                                                <li class="nav-item submenu-hide">
                                            <a href="https://nextformation.com/formations-metiers/formations-pedagogie-insertion-professionnelle" class="nav-link">
                                                <span>Formations Pédagogie & Insertion Professionnelle</span>
                                                                                                <span class="nav-link-icon fa"></span>
                                                                                            </a>
                                                                                        <ul class="nav nav-items">
                                                <li class="nav-item nav-item-static">
                                                    <a class="nav-link-parent">
                                                        <span class="nav-link-icon fa"></span> <span>Formations Pédagogie & Insertion Professionnelle</span>
                                                    </a>
                                                </li>
                                                                                                                                                <li class="nav-item">
                                                                                                        <p class="nav-section-label mb-0">Bac +2</p>
                                                                                                            <ul class="nav nav-items">
                                                                                                                    <li class="nav-item">
                                                            <a href="https://nextformation.com/formations-metiers/formations-pedagogie-insertion-professionnelle/formation-animateur-multimedia" class="nav-link">
                                                                Formation Conseiller numérique
                                                            </a>
                                                        </li>
                                                                                                                    <li class="nav-item">
                                                            <a href="https://nextformation.com/formations-metiers/formations-pedagogie-insertion-professionnelle/formation-conseiller-en-insertion-professionnelle" class="nav-link">
                                                                Formation Conseiller(e) en Insertion Professionnelle
                                                            </a>
                                                        </li>
                                                                                                                    <li class="nav-item">
                                                            <a href="https://nextformation.com/formations-metiers/formations-pedagogie-insertion-professionnelle/formation-formateur-pour-adultes" class="nav-link">
                                                                Formation de Formateur – Certifiante – Nextformation
                                                            </a>
                                                        </li>
                                                                                                                </ul>
                                                                                                                                                            </li>
                                                                                                <li class="nav-item nav-item-static nav-item-cta">
                                                    <a href="https://nextformation.com/formations-metiers/formations-pedagogie-insertion-professionnelle" class="btn btn-secondary">Visiter la page de la filière</a>
                                                </li>
                                            </ul>
                                                                                    </li>
                                                                                <li class="nav-item submenu-hide">
                                            <a href="https://nextformation.com/formations-metiers/formations-ressources-humaines-management" class="nav-link">
                                                <span>Formations Ressources Humaines & Management</span>
                                                                                                <span class="nav-link-icon fa"></span>
                                                                                            </a>
                                                                                        <ul class="nav nav-items">
                                                <li class="nav-item nav-item-static">
                                                    <a class="nav-link-parent">
                                                        <span class="nav-link-icon fa"></span> <span>Formations Ressources Humaines & Management</span>
                                                    </a>
                                                </li>
                                                                                                                                                <li class="nav-item nav-border-bottom">
                                                                                                        <p class="nav-section-label mb-0">Bac +2</p>
                                                                                                            <ul class="nav nav-items">
                                                                                                                    <li class="nav-item">
                                                            <a href="https://nextformation.com/formations-metiers/formations-ressources-humaines-management/formation-de-assistante-ressources-humaines" class="nav-link">
                                                                Formation de Assistant(e) Ressources Humaines
                                                            </a>
                                                        </li>
                                                                                                                    <li class="nav-item">
                                                            <a href="https://nextformation.com/formations-metiers/formations-ressources-humaines-management/formation-gestionnaire-de-paie" class="nav-link">
                                                                Formation Gestionnaire de Paie
                                                            </a>
                                                        </li>
                                                                                                                </ul>
                                                                                                                                                            </li>
                                                                                                                                                <li class="nav-item">
                                                                                                        <p class="nav-section-label mb-0">Bac +3</p>
                                                                                                            <ul class="nav nav-items">
                                                                                                                    <li class="nav-item">
                                                            <a href="https://nextformation.com/formations-metiers/formations-ressources-humaines-management/formation-de-responsable-ressources-humaines" class="nav-link">
                                                                Formation de Responsable Ressources Humaines
                                                            </a>
                                                        </li>
                                                                                                                </ul>
                                                                                                                                                            </li>
                                                                                                <li class="nav-item nav-item-static nav-item-cta">
                                                    <a href="https://nextformation.com/formations-metiers/formations-ressources-humaines-management" class="btn btn-secondary">Visiter la page de la filière</a>
                                                </li>
                                            </ul>
                                                                                    </li>
                                                                                <li class="nav-item submenu-hide">
                                            <a href="https://nextformation.com/formations-metiers/formations-secretariat-assistanat" class="nav-link">
                                                <span>Formations Secrétariat & Assistanat</span>
                                                                                                <span class="nav-link-icon fa"></span>
                                                                                            </a>
                                                                                        <ul class="nav nav-items">
                                                <li class="nav-item nav-item-static">
                                                    <a class="nav-link-parent">
                                                        <span class="nav-link-icon fa"></span> <span>Formations Secrétariat & Assistanat</span>
                                                    </a>
                                                </li>
                                                                                                                                                <li class="nav-item nav-border-bottom">
                                                                                                        <p class="nav-section-label mb-0">CAP/BEP</p>
                                                                                                            <ul class="nav nav-items">
                                                                                                                    <li class="nav-item">
                                                            <a href="https://nextformation.com/formations-metiers/formations-secretariat-assistanat/formation-assistante-de-vie-aux-familles-cap-bep" class="nav-link">
                                                                Formation Assistant(e) de Vie aux Familles
                                                            </a>
                                                        </li>
                                                                                                                </ul>
                                                                                                                                                            </li>
                                                                                                                                                <li class="nav-item nav-border-bottom">
                                                                                                        <p class="nav-section-label mb-0">Bac</p>
                                                                                                            <ul class="nav nav-items">
                                                                                                                    <li class="nav-item">
                                                            <a href="https://nextformation.com/formations-metiers/formations-secretariat-assistanat/formation-secretaire-assistante" class="nav-link">
                                                                Formation Secrétaire Assistant(e)
                                                            </a>
                                                        </li>
                                                                                                                    <li class="nav-item">
                                                            <a href="https://nextformation.com/formations-metiers/formations-secretariat-assistanat/formation-de-secretaire-medicale" class="nav-link">
                                                                Formation Secrétaire Médical(e)
                                                            </a>
                                                        </li>
                                                                                                                </ul>
                                                                                                                                                            </li>
                                                                                                                                                <li class="nav-item">
                                                                                                        <p class="nav-section-label mb-0">Bac +2</p>
                                                                                                            <ul class="nav nav-items">
                                                                                                                    <li class="nav-item">
                                                            <a href="https://nextformation.com/formations-metiers/formations-secretariat-assistanat/formation-assistante-de-direction" class="nav-link">
                                                                Formation Assistant(e) de Direction
                                                            </a>
                                                        </li>
                                                                                                                </ul>
                                                                                                                                                            </li>
                                                                                                <li class="nav-item nav-item-static nav-item-cta">
                                                    <a href="https://nextformation.com/formations-metiers/formations-secretariat-assistanat" class="btn btn-secondary">Visiter la page de la filière</a>
                                                </li>
                                            </ul>
                                                                                    </li>
                                                                                <li class="nav-item submenu-hide">
                                            <a href="https://nextformation.com/formations-metiers/formations-commerce-negociation-ventes" class="nav-link">
                                                <span>Formations Commerce, Négociation & Ventes</span>
                                                                                                <span class="nav-link-icon fa"></span>
                                                                                            </a>
                                                                                        <ul class="nav nav-items">
                                                <li class="nav-item nav-item-static">
                                                    <a class="nav-link-parent">
                                                        <span class="nav-link-icon fa"></span> <span>Formations Commerce, Négociation & Ventes</span>
                                                    </a>
                                                </li>
                                                                                                                                                <li class="nav-item">
                                                                                                        <p class="nav-section-label mb-0">Bac +2</p>
                                                                                                            <ul class="nav nav-items">
                                                                                                                    <li class="nav-item">
                                                            <a href="https://nextformation.com/formations-metiers/formations-commerce-negociation-ventes/formation-negociateur-technico-commerciale" class="nav-link">
                                                                Formation Négociateur(trice) Technico-Commercial(e)
                                                            </a>
                                                        </li>
                                                                                                                </ul>
                                                                                                                                                            </li>
                                                                                                <li class="nav-item nav-item-static nav-item-cta">
                                                    <a href="https://nextformation.com/formations-metiers/formations-commerce-negociation-ventes" class="btn btn-secondary">Visiter la page de la filière</a>
                                                </li>
                                            </ul>
                                                                                    </li>
                                                                            </ul>
                                </div></div>
                                                            </li>
                                                        <li class="nav-item submenu-hide maxi-menu">
                                                                <a class="nav-link">
                                                                    <span>Formations courtes</span>
                                                                        <span class="nav-link-icon fa"></span>
                                                                    </a>
                                                                <div class="mm-container-fluid"><div class="mm-container">

                                    

                                    <ul class="nav nav-items">
                                        <li class="nav-item">
                                            <a class="nav-link-parent">
                                                <span class="nav-link-icon fa"></span> <span>Formations courtes</span>
                                            </a>
                                        </li>
                                                                                <li class="nav-item submenu-hide">
                                            <a href="https://nextformation.com/formations-courtes/commerce-negociation-ventes" class="nav-link">
                                                <span>Commerce, Négociation & Ventes</span>
                                                                                                <span class="nav-link-icon fa"></span>
                                                                                            </a>
                                                                                        <ul class="nav nav-items">
                                                <li class="nav-item nav-item-static">
                                                    <a class="nav-link-parent">
                                                        <span class="nav-link-icon fa"></span> <span>Commerce, Négociation & Ventes</span>
                                                    </a>
                                                </li>
                                                                                                                                                <li class="nav-item py-0">
                                                                                                        <a href="https://nextformation.com/formations-courtes/commerce-negociation-ventes/elaborer-une-strategie-commerciale-zone-geographique" class="nav-link">
                                                        Elaborer une stratégie commerciale – zone géographique
                                                    </a>
                                                                                                    </li>
                                                                                                                                                <li class="nav-item py-0">
                                                                                                        <a href="https://nextformation.com/formations-courtes/commerce-negociation-ventes/prospecter-repondre-a-un-besoin-et-negocier" class="nav-link">
                                                        Prospecter, répondre à un besoin et négocier
                                                    </a>
                                                                                                    </li>
                                                                                                <li class="nav-item nav-item-static nav-item-cta">
                                                    <a href="https://nextformation.com/formations-courtes/commerce-negociation-ventes" class="btn btn-secondary">Visiter la page de la filière</a>
                                                </li>
                                            </ul>
                                                                                    </li>
                                                                                <li class="nav-item submenu-hide">
                                            <a href="https://nextformation.com/formations-courtes/comptabilite-finance" class="nav-link">
                                                <span>Comptabilité & Finance</span>
                                                                                                <span class="nav-link-icon fa"></span>
                                                                                            </a>
                                                                                        <ul class="nav nav-items">
                                                <li class="nav-item nav-item-static">
                                                    <a class="nav-link-parent">
                                                        <span class="nav-link-icon fa"></span> <span>Comptabilité & Finance</span>
                                                    </a>
                                                </li>
                                                                                                                                                <li class="nav-item py-0">
                                                                                                        <a href="https://nextformation.com/formations-courtes/comptabilite-finance/assurer-les-travaux-courants-de-comptabilite" class="nav-link">
                                                        Assurer les travaux courants de comptabilité
                                                    </a>
                                                                                                    </li>
                                                                                                                                                <li class="nav-item py-0">
                                                                                                        <a href="https://nextformation.com/formations-courtes/comptabilite-finance/preparer-la-paie-et-les-declarations-sociales" class="nav-link">
                                                        Préparer la paie et les déclarations sociales
                                                    </a>
                                                                                                    </li>
                                                                                                                                                <li class="nav-item py-0">
                                                                                                        <a href="https://nextformation.com/formations-courtes/comptabilite-finance/preparer-le-bilan-et-presenter-les-indicateurs-de-gestion" class="nav-link">
                                                        Préparer le bilan et présenter les indicateurs de gestion
                                                    </a>
                                                                                                    </li>
                                                                                                                                                <li class="nav-item py-0">
                                                                                                        <a href="https://nextformation.com/formations-courtes/comptabilite-finance/arreter-consolider-et-presenter-les-comptes-annuels" class="nav-link">
                                                        Arrêter, consolider et présenter les comptes annuels
                                                    </a>
                                                                                                    </li>
                                                                                                                                                <li class="nav-item py-0">
                                                                                                        <a href="https://nextformation.com/formations-courtes/comptabilite-finance/etablir-et-controler-les-declarations-fiscales" class="nav-link">
                                                        Etablir et contrôler les déclarations fiscales
                                                    </a>
                                                                                                    </li>
                                                                                                                                                <li class="nav-item py-0">
                                                                                                        <a href="https://nextformation.com/formations-courtes/comptabilite-finance/analyse-et-prevision-financiere" class="nav-link">
                                                        Analyse et prévision financière
                                                    </a>
                                                                                                    </li>
                                                                                                <li class="nav-item nav-item-static nav-item-cta">
                                                    <a href="https://nextformation.com/formations-courtes/comptabilite-finance" class="btn btn-secondary">Visiter la page de la filière</a>
                                                </li>
                                            </ul>
                                                                                    </li>
                                                                                <li class="nav-item submenu-hide">
                                            <a href="https://nextformation.com/formations-courtes/developpement-informatique" class="nav-link">
                                                <span>Développement informatique</span>
                                                                                                <span class="nav-link-icon fa"></span>
                                                                                            </a>
                                                                                        <ul class="nav nav-items">
                                                <li class="nav-item nav-item-static">
                                                    <a class="nav-link-parent">
                                                        <span class="nav-link-icon fa"></span> <span>Développement informatique</span>
                                                    </a>
                                                </li>
                                                                                                                                                <li class="nav-item py-0">
                                                                                                        <a href="https://nextformation.com/formations-courtes/developpement-informatique/developper-le-front-end-dune-application-web" class="nav-link">
                                                        Développer le front-end d’une application web
                                                    </a>
                                                                                                    </li>
                                                                                                                                                <li class="nav-item py-0">
                                                                                                        <a href="https://nextformation.com/formations-courtes/developpement-informatique/developper-le-back-end-dune-application-web" class="nav-link">
                                                        Développer le back-end d’une application web
                                                    </a>
                                                                                                    </li>
                                                                                                <li class="nav-item nav-item-static nav-item-cta">
                                                    <a href="https://nextformation.com/formations-courtes/developpement-informatique" class="btn btn-secondary">Visiter la page de la filière</a>
                                                </li>
                                            </ul>
                                                                                    </li>
                                                                                <li class="nav-item submenu-hide">
                                            <a href="https://nextformation.com/formations-courtes/marketing-communication-design" class="nav-link">
                                                <span>Marketing, Communication & Design</span>
                                                                                                <span class="nav-link-icon fa"></span>
                                                                                            </a>
                                                                                        <ul class="nav nav-items">
                                                <li class="nav-item nav-item-static">
                                                    <a class="nav-link-parent">
                                                        <span class="nav-link-icon fa"></span> <span>Marketing, Communication & Design</span>
                                                    </a>
                                                </li>
                                                                                                                                                <li class="nav-item py-0">
                                                                                                        <a href="https://nextformation.com/formations-courtes/marketing-communication-design/oncevoir-supports-communication-digitaux" class="nav-link">
                                                        Formation Concevoir des supports de communication digitaux
                                                    </a>
                                                                                                    </li>
                                                                                                                                                <li class="nav-item py-0">
                                                                                                        <a href="https://nextformation.com/formations-courtes/marketing-communication-design/gestion-projet-numerique" class="nav-link">
                                                        Formation Gestion de projet numérique
                                                    </a>
                                                                                                    </li>
                                                                                                                                                <li class="nav-item py-0">
                                                                                                        <a href="https://nextformation.com/formations-courtes/marketing-communication-design/creation-de-site-web" class="nav-link">
                                                        Formation Création de site web
                                                    </a>
                                                                                                    </li>
                                                                                                <li class="nav-item nav-item-static nav-item-cta">
                                                    <a href="https://nextformation.com/formations-courtes/marketing-communication-design" class="btn btn-secondary">Visiter la page de la filière</a>
                                                </li>
                                            </ul>
                                                                                    </li>
                                                                                <li class="nav-item submenu-hide">
                                            <a href="https://nextformation.com/formations-courtes/pedagogie-insertion-professionnelle" class="nav-link">
                                                <span>Pédagogie & Insertion Professionnelle</span>
                                                                                                <span class="nav-link-icon fa"></span>
                                                                                            </a>
                                                                                        <ul class="nav nav-items">
                                                <li class="nav-item nav-item-static">
                                                    <a class="nav-link-parent">
                                                        <span class="nav-link-icon fa"></span> <span>Pédagogie & Insertion Professionnelle</span>
                                                    </a>
                                                </li>
                                                                                                                                                <li class="nav-item py-0">
                                                                                                        <a href="https://nextformation.com/formations-courtes/pedagogie-insertion-professionnelle/coach-numerique" class="nav-link">
                                                        Formation Coach numérique
                                                    </a>
                                                                                                    </li>
                                                                                                                                                <li class="nav-item py-0">
                                                                                                        <a href="https://nextformation.com/formations-courtes/pedagogie-insertion-professionnelle/developpement-espace-mediation-numerique" class="nav-link">
                                                        Formation Contribuer au développement d’un espace de médiation numérique et de ses projets
                                                    </a>
                                                                                                    </li>
                                                                                                                                                <li class="nav-item py-0">
                                                                                                        <a href="https://nextformation.com/formations-courtes/pedagogie-insertion-professionnelle/gestion-espace-mediation-numerique" class="nav-link">
                                                        Formation gestion d’un espace de médiation numérique
                                                    </a>
                                                                                                    </li>
                                                                                                                                                <li class="nav-item py-0">
                                                                                                        <a href="https://nextformation.com/formations-courtes/pedagogie-insertion-professionnelle/analyser-et-favoriser-linsertion-professionnelle" class="nav-link">
                                                        Analyser et favoriser l'insertion professionnelle
                                                    </a>
                                                                                                    </li>
                                                                                                                                                <li class="nav-item py-0">
                                                                                                        <a href="https://nextformation.com/formations-courtes/pedagogie-insertion-professionnelle/guider-les-personnes-dans-leur-parcours-dinsertion" class="nav-link">
                                                        Guider les personnes dans leur parcours d’insertion
                                                    </a>
                                                                                                    </li>
                                                                                                                                                <li class="nav-item py-0">
                                                                                                        <a href="https://nextformation.com/formations-courtes/pedagogie-insertion-professionnelle/developper-un-reseau-dentreprises-pour-favoriser-linsertion" class="nav-link">
                                                        Développer un réseau d’entreprises pour favoriser l’insertion
                                                    </a>
                                                                                                    </li>
                                                                                                                                                <li class="nav-item py-0">
                                                                                                        <a href="https://nextformation.com/formations-courtes/pedagogie-insertion-professionnelle/preparer-et-animer-des-formations-pour-adultes" class="nav-link">
                                                        Préparer et animer des formations pour adultes
                                                    </a>
                                                                                                    </li>
                                                                                                                                                <li class="nav-item py-0">
                                                                                                        <a href="https://nextformation.com/formations-courtes/pedagogie-insertion-professionnelle/delivrer-des-formations-personnalisees-et-individualisees" class="nav-link">
                                                        Délivrer des formations personnalisées et individualisées
                                                    </a>
                                                                                                    </li>
                                                                                                <li class="nav-item nav-item-static nav-item-cta">
                                                    <a href="https://nextformation.com/formations-courtes/pedagogie-insertion-professionnelle" class="btn btn-secondary">Visiter la page de la filière</a>
                                                </li>
                                            </ul>
                                                                                    </li>
                                                                                <li class="nav-item submenu-hide">
                                            <a href="https://nextformation.com/formations-courtes/ressources-humaines" class="nav-link">
                                                <span>Ressources Humaines</span>
                                                                                                <span class="nav-link-icon fa"></span>
                                                                                            </a>
                                                                                        <ul class="nav nav-items">
                                                <li class="nav-item nav-item-static">
                                                    <a class="nav-link-parent">
                                                        <span class="nav-link-icon fa"></span> <span>Ressources Humaines</span>
                                                    </a>
                                                </li>
                                                                                                                                                <li class="nav-item py-0">
                                                                                                        <a href="https://nextformation.com/formations-courtes/ressources-humaines/formation-pilotage-et-deploiement-des-processus-rh" class="nav-link">
                                                        Formation Pilotage et déploiement des processus RH
                                                    </a>
                                                                                                    </li>
                                                                                                                                                <li class="nav-item py-0">
                                                                                                        <a href="https://nextformation.com/formations-courtes/ressources-humaines/formation-manager-un-projet-rh" class="nav-link">
                                                        Formation Manager un projet RH
                                                    </a>
                                                                                                    </li>
                                                                                                                                                <li class="nav-item py-0">
                                                                                                        <a href="https://nextformation.com/formations-courtes/ressources-humaines/formation-developper-une-politique-de-developpement-rh" class="nav-link">
                                                        Formation Développer une politique de développement RH
                                                    </a>
                                                                                                    </li>
                                                                                                                                                <li class="nav-item py-0">
                                                                                                        <a href="https://nextformation.com/formations-courtes/ressources-humaines/assister-la-gestion-des-ressources-humaines" class="nav-link">
                                                        Assister la gestion des ressources humaines
                                                    </a>
                                                                                                    </li>
                                                                                                                                                <li class="nav-item py-0">
                                                                                                        <a href="https://nextformation.com/formations-courtes/ressources-humaines/contribuer-au-developpement-des-ressources-humaines" class="nav-link">
                                                        Contribuer au développement des ressources humaines
                                                    </a>
                                                                                                    </li>
                                                                                                                                                <li class="nav-item py-0">
                                                                                                        <a href="https://nextformation.com/formations-courtes/ressources-humaines/gestion-sociale-des-entreprises" class="nav-link">
                                                        Gestion sociale des entreprises
                                                    </a>
                                                                                                    </li>
                                                                                                                                                <li class="nav-item py-0">
                                                                                                        <a href="https://nextformation.com/formations-courtes/ressources-humaines/gestion-de-la-paie" class="nav-link">
                                                        Gestion de la paie
                                                    </a>
                                                                                                    </li>
                                                                                                                                                <li class="nav-item py-0">
                                                                                                        <a href="https://nextformation.com/formations-courtes/ressources-humaines/developper-les-projets-rh" class="nav-link">
                                                        Développer les projets RH
                                                    </a>
                                                                                                    </li>
                                                                                                                                                <li class="nav-item py-0">
                                                                                                        <a href="https://nextformation.com/formations-courtes/ressources-humaines/gerer-les-ressources-humaines" class="nav-link">
                                                        Gérer les Ressources Humaines
                                                    </a>
                                                                                                    </li>
                                                                                                                                                <li class="nav-item py-0">
                                                                                                        <a href="https://nextformation.com/formations-courtes/ressources-humaines/mettre-en-oeuvre-la-strategie-de-communication-rh" class="nav-link">
                                                        Mettre en œuvre la stratégie de communication RH
                                                    </a>
                                                                                                    </li>
                                                                                                <li class="nav-item nav-item-static nav-item-cta">
                                                    <a href="https://nextformation.com/formations-courtes/ressources-humaines" class="btn btn-secondary">Visiter la page de la filière</a>
                                                </li>
                                            </ul>
                                                                                    </li>
                                                                                <li class="nav-item submenu-hide">
                                            <a href="https://nextformation.com/formations-courtes/secretariat-assistanat" class="nav-link">
                                                <span>Secrétariat & Assistanat</span>
                                                                                                <span class="nav-link-icon fa"></span>
                                                                                            </a>
                                                                                        <ul class="nav nav-items">
                                                <li class="nav-item nav-item-static">
                                                    <a class="nav-link-parent">
                                                        <span class="nav-link-icon fa"></span> <span>Secrétariat & Assistanat</span>
                                                    </a>
                                                </li>
                                                                                                                                                <li class="nav-item py-0">
                                                                                                        <a href="https://nextformation.com/formations-courtes/secretariat-assistanat/assister-la-direction" class="nav-link">
                                                        Assister la direction
                                                    </a>
                                                                                                    </li>
                                                                                                                                                <li class="nav-item py-0">
                                                                                                        <a href="https://nextformation.com/formations-courtes/secretariat-assistanat/developper-la-collaboration-et-la-communication-interne" class="nav-link">
                                                        Développer la collaboration et la communication interne
                                                    </a>
                                                                                                    </li>
                                                                                                                                                <li class="nav-item py-0">
                                                                                                        <a href="https://nextformation.com/formations-courtes/secretariat-assistanat/assistant-gestion-de-projet" class="nav-link">
                                                        Assistant : gestion de projet
                                                    </a>
                                                                                                    </li>
                                                                                                                                                <li class="nav-item py-0">
                                                                                                        <a href="https://nextformation.com/formations-courtes/secretariat-assistanat/entretenir-le-logement-et-le-linge-dun-particulier" class="nav-link">
                                                        Entretenir le logement et le linge d’un particulier
                                                    </a>
                                                                                                    </li>
                                                                                                                                                <li class="nav-item py-0">
                                                                                                        <a href="https://nextformation.com/formations-courtes/secretariat-assistanat/accompagner-une-personne-dependante-dans-son-quotidien" class="nav-link">
                                                        Accompagner une personne dépendante dans son quotidien
                                                    </a>
                                                                                                    </li>
                                                                                                                                                <li class="nav-item py-0">
                                                                                                        <a href="https://nextformation.com/formations-courtes/secretariat-assistanat/garder-des-enfants-a-domicile" class="nav-link">
                                                        Garder des enfants à domicile
                                                    </a>
                                                                                                    </li>
                                                                                                                                                <li class="nav-item py-0">
                                                                                                        <a href="https://nextformation.com/formations-courtes/secretariat-assistanat/gerer-et-organiser-laccueil-en-entreprise" class="nav-link">
                                                        Gérer et organiser l’accueil en entreprise
                                                    </a>
                                                                                                    </li>
                                                                                                                                                <li class="nav-item py-0">
                                                                                                        <a href="https://nextformation.com/formations-courtes/secretariat-assistanat/gerer-ladministration-commerciale-et-le-suivi-du-personnel" class="nav-link">
                                                        Gérer l'administration commerciale et le suivi du personnel
                                                    </a>
                                                                                                    </li>
                                                                                                                                                <li class="nav-item py-0">
                                                                                                        <a href="https://nextformation.com/formations-courtes/secretariat-assistanat/accueillir-un-patient-et-gerer-son-dossier-administratif" class="nav-link">
                                                        Accueillir un patient et gérer son dossier administratif
                                                    </a>
                                                                                                    </li>
                                                                                                                                                <li class="nav-item py-0">
                                                                                                        <a href="https://nextformation.com/formations-courtes/secretariat-assistanat/gestion-administrative-et-suivi-dun-patient" class="nav-link">
                                                        Gestion administrative et suivi d’un patient
                                                    </a>
                                                                                                    </li>
                                                                                                <li class="nav-item nav-item-static nav-item-cta">
                                                    <a href="https://nextformation.com/formations-courtes/secretariat-assistanat" class="btn btn-secondary">Visiter la page de la filière</a>
                                                </li>
                                            </ul>
                                                                                    </li>
                                                                                <li class="nav-item submenu-hide">
                                            <a href="https://nextformation.com/formations-courtes/securite-systemes-reseaux" class="nav-link">
                                                <span>Sécurité, Systèmes & Réseaux</span>
                                                                                                <span class="nav-link-icon fa"></span>
                                                                                            </a>
                                                                                        <ul class="nav nav-items">
                                                <li class="nav-item nav-item-static">
                                                    <a class="nav-link-parent">
                                                        <span class="nav-link-icon fa"></span> <span>Sécurité, Systèmes & Réseaux</span>
                                                    </a>
                                                </li>
                                                                                                                                                <li class="nav-item py-0">
                                                                                                        <a href="https://nextformation.com/formations-courtes/securite-systemes-reseaux/mettre-en-service-des-equipements-informatiques" class="nav-link">
                                                        Mettre en service des équipements informatiques
                                                    </a>
                                                                                                    </li>
                                                                                                                                                <li class="nav-item py-0">
                                                                                                        <a href="https://nextformation.com/formations-courtes/securite-systemes-reseaux/assurer-la-maintenance-dun-parc-informatique" class="nav-link">
                                                        Assurer la maintenance d’un parc informatique
                                                    </a>
                                                                                                    </li>
                                                                                                                                                <li class="nav-item py-0">
                                                                                                        <a href="https://nextformation.com/formations-courtes/securite-systemes-reseaux/assister-les-utilisateurs-dun-parc-informatique" class="nav-link">
                                                        Assister les utilisateurs d’un parc informatique
                                                    </a>
                                                                                                    </li>
                                                                                                                                                <li class="nav-item py-0">
                                                                                                        <a href="https://nextformation.com/formations-courtes/securite-systemes-reseaux/assister-les-utilisateurs-en-centre-de-services" class="nav-link">
                                                        Assister les utilisateurs en centre de services
                                                    </a>
                                                                                                    </li>
                                                                                                                                                <li class="nav-item py-0">
                                                                                                        <a href="https://nextformation.com/formations-courtes/securite-systemes-reseaux/maintenir-exploiter-et-securiser-un-si-centralise" class="nav-link">
                                                        Maintenir, exploiter et sécuriser un SI centralisé
                                                    </a>
                                                                                                    </li>
                                                                                                                                                <li class="nav-item py-0">
                                                                                                        <a href="https://nextformation.com/formations-courtes/securite-systemes-reseaux/maintenir-exploiter-et-securiser-un-si-distribue" class="nav-link">
                                                        Maintenir, exploiter et sécuriser un SI distribué
                                                    </a>
                                                                                                    </li>
                                                                                                                                                <li class="nav-item py-0">
                                                                                                        <a href="https://nextformation.com/formations-courtes/securite-systemes-reseaux/administrer-et-securiser-les-infrastructures-si" class="nav-link">
                                                        Administrer et sécuriser les infrastructures SI
                                                    </a>
                                                                                                    </li>
                                                                                                                                                <li class="nav-item py-0">
                                                                                                        <a href="https://nextformation.com/formations-courtes/securite-systemes-reseaux/administrer-et-securiser-une-infrastructure-distribuee" class="nav-link">
                                                        Administrer et sécuriser une infrastructure distribuée
                                                    </a>
                                                                                                    </li>
                                                                                                                                                <li class="nav-item py-0">
                                                                                                        <a href="https://nextformation.com/formations-courtes/securite-systemes-reseaux/optimiser-le-si-et-son-niveau-de-securite" class="nav-link">
                                                        Optimiser le SI et son niveau de sécurité
                                                    </a>
                                                                                                    </li>
                                                                                                <li class="nav-item nav-item-static nav-item-cta">
                                                    <a href="https://nextformation.com/formations-courtes/securite-systemes-reseaux" class="btn btn-secondary">Visiter la page de la filière</a>
                                                </li>
                                            </ul>
                                                                                    </li>
                                                                            </ul>
                                </div></div>
                                                            </li>
                                                        <li class="nav-item submenu-hide ">
                                                                <a href="https://nextformation.com/financements" class="nav-link">
                                                                    <span>Financer sa formation</span>
                                                                    </a>
                                                            </li>
                                                        <li class="nav-item submenu-hide ">
                                                                <a class="nav-link">
                                                                    <span>La vie chez Next</span>
                                                                        <span class="nav-link-icon fa"></span>
                                                                    </a>
                                                                <div class="mm-container-fluid"><div class="mm-container">

                                    

                                    <ul class="nav nav-items">
                                        <li class="nav-item">
                                            <a class="nav-link-parent">
                                                <span class="nav-link-icon fa"></span> <span>La vie chez Next</span>
                                            </a>
                                        </li>
                                                                                <li class="nav-item submenu-hide">
                                            <a href="https://nextformation.com/la-vie-chez-next/nos-centres-de-formation-a-paris-et-ile-de-france" class="nav-link">
                                                <span>Nos centres de formation à Paris et île-de-France</span>
                                                                                            </a>
                                                                                    </li>
                                                                                <li class="nav-item submenu-hide">
                                            <a href="https://nextformation.com/la-vie-chez-next/le-quotidien" class="nav-link">
                                                <span>Le quotidien</span>
                                                                                            </a>
                                                                                    </li>
                                                                                <li class="nav-item submenu-hide">
                                            <a href="https://nextformation.com/la-vie-chez-next/nos-evenements" class="nav-link">
                                                <span>Nos évènements</span>
                                                                                            </a>
                                                                                    </li>
                                                                                <li class="nav-item submenu-hide">
                                            <a href="https://nextformation.com/la-vie-chez-next/temoignages" class="nav-link">
                                                <span>Nos témoignages</span>
                                                                                            </a>
                                                                                    </li>
                                                                            </ul>
                                </div></div>
                                                            </li>
                                                        <li class="nav-item submenu-hide ">
                                                                <a class="nav-link">
                                                                    <span>Pédagogie</span>
                                                                        <span class="nav-link-icon fa"></span>
                                                                    </a>
                                                                <div class="mm-container-fluid"><div class="mm-container">

                                    

                                    <ul class="nav nav-items">
                                        <li class="nav-item">
                                            <a class="nav-link-parent">
                                                <span class="nav-link-icon fa"></span> <span>Pédagogie</span>
                                            </a>
                                        </li>
                                                                                <li class="nav-item submenu-hide">
                                            <a href="https://nextformation.com/pedagogie/notre-pedagogie" class="nav-link">
                                                <span>Notre Pédagogie</span>
                                                                                            </a>
                                                                                    </li>
                                                                                <li class="nav-item submenu-hide">
                                            <a href="https://nextformation.com/pedagogie/formations-a-distance" class="nav-link">
                                                <span>Formations à distance chez Nextformation</span>
                                                                                            </a>
                                                                                    </li>
                                                                                <li class="nav-item submenu-hide">
                                            <a href="https://nextformation.com/pedagogie/formations-en-presentiel" class="nav-link">
                                                <span>Formations en présentiel chez Nextformation</span>
                                                                                            </a>
                                                                                    </li>
                                                                                <li class="nav-item submenu-hide">
                                            <a href="https://nextformation.com/pedagogie/formez-vos-salaries" class="nav-link">
                                                <span>Formez vos salariés</span>
                                                                                            </a>
                                                                                    </li>
                                                                                <li class="nav-item submenu-hide">
                                            <a href="https://nextformation.com/pedagogie/accessibilite-aux-publics-en-situation-de-handicap" class="nav-link">
                                                <span>Accessibilité aux publics en situation de handicap</span>
                                                                                            </a>
                                                                                    </li>
                                                                            </ul>
                                </div></div>
                                                            </li>
                                                        <li class="nav-item submenu-hide ">
                                                                <a href="https://nextformation.com/blog" class="nav-link" target=&quot;_blank&quot;>
                                                                    <span>Le blog</span>
                                                                    </a>
                                                            </li>
                                                    </ul>
                    </div>
                </div>


                
                <div id="menu-secondary" class="menu-hide order-xl-1">
                    <div class="container">
                    
                        
                        <div class="menu-brand">
                            <a class="menu-brand-logo" href="https://nextformation.com" target="_top">
                                <span class="sr-only">Nextformation</span>
                                <img data-src="https://nextformation.com/app/themes/nextformation/dist/images/common/nextformation_logo_38470f5e.png" alt="Nextformation" />
                            </a>
                        </div>
                        
                        <ul class="navbar-nav nav-items">
                                                        <li class="nav-item nav-item-sep">
                                                                    <a href="https://nextformation.com/notre-histoire" class="nav-link">Qui sommes-nous</a>
                                                            </li>
                                                        <li class="nav-item nav-item-sep">
                                                                    <a href="https://nextformation.com/nous-contacter" class="nav-link">Nous contacter</a>
                                                            </li>
                                                    </ul>

                        <div class="nav-socials">
                            <ul class="share-buttons variant-grey">
          <li class="share-button"><a href="https://www.facebook.com/Nextformation/" target="_blank" class="share-link fab fa-facebook" aria-label="https://www.facebook.com/Nextformation/"></a></li>
          <li class="share-button"><a href="https://twitter.com/nextformation" target="_blank" class="share-link fab fa-twitter" aria-label="https://twitter.com/nextformation"></a></li>
          <li class="share-button"><a href="https://fr.linkedin.com/company/nextformation/" target="_blank" class="share-link fab fa-linkedin" aria-label="https://fr.linkedin.com/company/nextformation/"></a></li>
          <li class="share-button"><a href="https://www.instagram.com/nextformation_officiel/" target="_blank" class="share-link fab fa-instagram" aria-label="https://www.instagram.com/nextformation_officiel/"></a></li>
          <li class="share-button"><a href="https://www.youtube.com/channel/UCBW6gvq0ab7bqcpl9PLVRaQ" target="_blank" class="share-link fab fa-youtube" aria-label="https://www.youtube.com/channel/UCBW6gvq0ab7bqcpl9PLVRaQ"></a></li>
        </ul>
                        </div>
                    </div>
                </div>


            </div>
        </div>
        
        <header class="container-fluid page-title page-title-center" style="--header-background: url(&#039;https://nextformation.com/app/themes/nextformation/dist/images/common/nf-header-dft-dsktp_42b5f544.jpg&#039;); --header-background-m: url(&#039;https://nextformation.com/app/themes/nextformation/dist/images/common/nf-header-dft-mbl_8c135d19.jpg&#039;);">
    <div class="container text-center header-content">

        <nav id="breadcrumb">
      <ul class="list-unstyled"><li><a href="https://nextformation.com">Accueil</a></li></ul>
    </nav>
    
    <h1 class="text_styled"><span>Oups</span> Erreur 404</h1>

    
        <form class="page-search page-subcontent" id="form-training-search">
      <div class="form-group">
        <label for="job_search" class="sr-only">Trouvez une formation, un métier</label>
        <div class="input-group input-group-lg">
          <input type="text" class="form-control" id="job_search" placeholder="Trouvez une formation, un métier...">
          <div class="input-group-append">
            <button type="submit" class="btn btn-primary border-0"><i class="fas fa-search"></i></button>
          </div>
        </div>
        <div class="dropdown">
          <span class="toggle-results sr-only" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" role="menu">Résultats</span>
          <div class="dropdown-menu"></div>
        </div>
      </div>
    </form>

          
        <div class="page-404-cta text-center mt-5">
      <a href="https://nextformation.com" class="btn btn-secondary">Retour accueil</a>
    </div>
    
    
  </div>
</header>




        <div id="page-body">
            
            <a name="page-body"></a>

                            

<div class="container-fluid bg-gray-100">

    <section class="page-content">

        <div class="row">

            <div class="col col-12">
                &nbsp;
            </div>

        </div>

    </section>

</div>


                    
        </div>

        <footer class="text-white">

  <div class="container">
    <div class="container-fluid">

      <div class="row">
        <div class="col-12 col-md-3">
          <figure class="pr-5 text-md-center">
            <img data-src="https://nextformation.com/app/themes/nextformation/dist/images/common/nextformation_logo_w_3_b3c3c10d.png" alt="Logo NextFormation" width="222" />
          </figure>
        </div>
        <div class="col-12 col-md-3">
          <figure class="text-md-center">
            <img data-src="https://nextformation.com/app/themes/nextformation/dist/images/common/logo_partner_qpqf_230dcd2b.svg" alt="Partenaire QPQF 2017" class="d-md-inline-block" />
            <img data-src="https://nextformation.com/app/themes/nextformation/dist/images/common/logo_partner_ffp_c0d38609.svg" alt="Partenaire FFP" class="d-md-inline-block" />
            <img data-src="https://nextformation.com/app/themes/nextformation/dist/images/common/logo_partner_datadock_0c955e02.svg" alt="Partenaire Datadock" class="d-md-inline-block" />
            <img data-src="https://nextformation.com/app/themes/nextformation/dist/images/common/logo_certification_qualiopi_15fa662c.png" alt="Certification Qualiopi" class="d-md-inline-block" />
            <img data-src="https://nextformation.com/app/themes/nextformation/dist/images/common/logo_charte_deontologie_cpf_8e99187a.png" alt="Charte Déontologie CPF" class="d-md-inline-block" style="max-width: 80px;" />
          </figure>
        </div>
        <div class="col-12 col-md-6">
          <p class="mb-5 mb-md-0 fsize-md-sm">
            Depuis 2002, Nextformation est un centre de formation basé à Paris et en Ile de France et spécialisé dans la formation professionnelle pour adultes en reconversion professionnelle, transition professionnelle, réorientation et évolution professionnelle via des formations diplômantes ou des formations continues délivrant des certifications et titres professionnels reconnus par l’Etat, le Ministère du Travail et répertoriées au RNCP. Nextformation est un organisme de formation qualifié ISQ-OPQF (certification qualité délivrée par l’Etat sur base de la qualité des formations professionnelles, de la satisfaction des clients, du respect de la réglementation etc.), agrée Datadock et membre de la FFP (Fédération de la Formation Professionnelle). Nos formations sont finançables par Transitions Pro, l’Agefiph, l’Afdas etc. via des dispositifs de financement comme le CPF, le CPF de transition Professionnelle, PSE, FNE, PDV, POEIC, POEC… Nous sommes fiers d’afficher un taux de réussite aux examens de 94%.
          </p>
        </div>
      </div>

      <hr class="sep" />

      <div class="row">

                <div class="col-12 col-md-3 footer-col-1">
          <div class="col-content">
                        <p class="btn-toggler no-textstyle" data-target="footer .footer-col-1" data-toggle-group="footer-toggler"><span>Nextformation</span> <span class="fa fa-angle-down"></span></p>
                                    <ul class="nav flex-column">
                                          <li class="nav-item"><a hhref="https://nextformation.com/pedagogie/notre-pedagogie"  class="hhref"> Notre Pédagogie</a></li>
                                          <li class="nav-item"><a hhref="https://nextformation.com/financements"  class="hhref"> Financer sa formation</a></li>
                                          <li class="nav-item"><a hhref="https://nextformation.com/la-vie-chez-next/le-quotidien"  class="hhref"> La vie chez Next</a></li>
                                          <li class="nav-item"><a hhref="https://nextformation.com/la-vie-chez-next/temoignages"  class="hhref"> Ils ont changé de métier</a></li>
                                          <li class="nav-item"><a hhref="https://taleez.com/careers/nextgroup"  target="_blank" class="hhref"> Nous rejoindre</a></li>
                                          <li class="nav-item"><a hhref="https://nextformation.com/fiches-metiers"  class="hhref"> Fiches métiers</a></li>
                          </ul>
                      </div>
        </div>

                <div class="col-12 col-md-3 footer-col-2">
          <div class="col-content">
                        <p class="btn-toggler no-textstyle" data-target="footer .footer-col-2" data-toggle-group="footer-toggler"><span>Nos formations</span> <span class="fa fa-angle-down"></span></p>
                                    <ul class="nav flex-column">
                                          <li class="nav-item"><a hhref="https://nextformation.com/formations-metiers/formations-comptabilite-gestion"  class="hhref"> Formation Comptabilité & Gestion</a></li>
                                          <li class="nav-item"><a hhref="https://nextformation.com/formations-metiers/formations-informatique-developpement-reseaux"  class="hhref"> Formation Informatique, Développement & Réseaux</a></li>
                                          <li class="nav-item"><a hhref="https://nextformation.com/formations-metiers/formations-marketing-communication-design"  class="hhref"> Formation Marketing, Communication & Design</a></li>
                                          <li class="nav-item"><a hhref="https://nextformation.com/formations-metiers/formations-pedagogie-insertion-professionnelle"  class="hhref"> Formation Pédagogie & Insertion Professionnelle</a></li>
                                          <li class="nav-item"><a hhref="https://nextformation.com/formations-metiers/formations-ressources-humaines-management"  class="hhref"> Formation Ressources Humaines & Management</a></li>
                                          <li class="nav-item"><a hhref="https://nextformation.com/formations-metiers/formations-secretariat-assistanat"  class="hhref"> Formation Secrétariat & Assistanat</a></li>
                                          <li class="nav-item"><a hhref="https://nextformation.com/formations-metiers/formations-commerce-negociation-ventes"  class="hhref"> Formation Commerce, Négociation & Ventes</a></li>
                          </ul>
                      </div>
        </div>

                <div class="col-12 col-md-3 footer-col-3">
          <div class="col-content">
                        <p class="btn-toggler no-textstyle" data-target="footer .footer-col-3" data-toggle-group="footer-toggler"><span>Nos centres de formation</span> <span class="fa fa-angle-down"></span></p>
                                    <ul class="nav flex-column">
                                          <li class="nav-item"><a hhref="https://nextformation.com/la-vie-chez-next/nos-centres-de-formation-a-paris-et-ile-de-france/opera"  class="hhref"> Espace Opéra</a></li>
                                          <li class="nav-item"><a hhref="https://nextformation.com/la-vie-chez-next/nos-centres-de-formation-a-paris-et-ile-de-france/vincennes"  class="hhref"> Espace Vincennes</a></li>
                                          <li class="nav-item"><a hhref="https://nextformation.com/la-vie-chez-next/nos-centres-de-formation-a-paris-et-ile-de-france/porte-de-versailles"  class="hhref"> Espace Porte de Versailles</a></li>
                                          <li class="nav-item"><a hhref="tel:+33142037700"  class="hhref"><span class="fa fa-phone-alt"></span> +33 1 42 03 77 00</a></li>
                                          <li class="nav-item"><a hhref="https://nextformation.com/nous-contacter"  class="hhref"><span class="fa fa-at"></span> Contactez-nous</a></li>
                          </ul>
                      </div>
        </div>

                <div class="col-12 col-md-3 footer-col-4">
          <div class="col-content">
                        <p class="btn-toggler no-textstyle" data-target="footer .footer-col-4" data-toggle-group="footer-toggler"><span>Le groupe</span> <span class="fa fa-angle-down"></span></p>
                                    <ul class="nav flex-column">
                                          <li class="nav-item"><a hhref="https://www.nextgroup.fr/"  target="_blank" class="hhref"> Le Groupe</a></li>
                                          <li class="nav-item"><a hhref="https://eimparis.com/"  class="hhref"> EIMParis</a></li>
                                          <li class="nav-item"><a hhref="https://webitechparis.com/"  class="hhref"> Webitech</a></li>
                          </ul>
                        <ul class="nav text-white footer-nav-socials mt-2">
              <li class="nav-item px-2"><a hhref="https://www.facebook.com/Nextformation/" target="_blank" class="fab fa-facebook hhref"></a></li>
              <li class="nav-item px-2"><a hhref="https://twitter.com/nextformation" target="_blank" class="fab fa-twitter hhref"></a></li>
              <li class="nav-item px-2"><a hhref="https://fr.linkedin.com/company/nextformation/" target="_blank" class="fab fa-linkedin hhref"></a></li>
              <li class="nav-item px-2"><a hhref="https://www.instagram.com/nextformation_officiel/?hl=fr" target="_blank" class="fab fa-instagram hhref"></a></li>
              <li class="nav-item px-2"><a hhref="https://www.youtube.com/user/nextformation" target="_blank" class="fab fa-youtube hhref"></a></li>
            </ul>
          </div>
        </div>
      </div>

                  <div class="row">
        <div class="col-12 col-md-3 mt-4 footer-mentions">
            <ul class="nav flex-column">
                                          <li class="nav-item"><a href="#CookiesAgreement"  class="hhref"> Paramètres cookies</a></li>
                                          <li class="nav-item"><a hhref="https://nextformation.com/mentions-legales"  class="hhref"> Mentions légales</a></li>
                                          <li class="nav-item"><a hhref="https://nextformation.com/conditions-generales-de-vente"  class="hhref"> CGV</a></li>
                          </ul>
        </div>
      </div>
          </div>
  </div>

</footer>

<div id="cookies-rgpd" class="container-fluid" style="display: none;">
    <div class="prevent-mouse-events"></div>
    <div class="block-position">
        <div class="container">
            <div class="row">
                <div class="col-12 mx-auto text-right pr-5" style="pointer-events: all; cursor: pointer;">
                    <!-- span class="action-link-sep"></span -->
                    <a onclick="window.LCCookiesUI.lc.confirm(); return false;" class="action-link text-white modalCookie"><span aria-hidden="true">&times;</span> Refuser et fermer</a>
                </div>
            </div>
            <div class="card bg-primary text-white">
                <div class="container step step-1">
                    <div class="row">
                        <div class="col-12 col-lg-8 mx-auto text-center">
                            <h6 class="mb-4">Chez Nextformation, nous respectons votre vie privée</h6>
                            <p>En poursuivant votre navigation sur ce site, vous acceptez l’utilisation de Cookies pour réaliser des statistiques de visites. Pour en savoir plus, visitez nos mentions légales.</p>
                        </div>
                    </div>
                    <div class="row mt-3">
                        <div class="col-12 col-lg-8 mx-auto text-center">
                            <a class="action-link btn btn-toggler text-white" data-target="#cookies-rgpd" data-toggle="step-params">Paramétrer</a>
                            <!-- span class="action-link-sep"></span -->
                            <a onclick="window.LCCookiesUI.lc.accept_all(); return false;" class="action-link action-push btn btn-white modalCookie">Tout accepter</a>
                        </div>
                    </div>
                </div>
                <div class="container step step-2">
                    <div class="row">
                        <div class="col-4 col-tabmenu">
                            <div class="list-group" id="cookies-partners-menu" role="tablist">
    
                                <a class="menu-item active" id="cookies-partner-menu-2" data-toggle="list" href="#" data-target="#cookies-partners-tabs .tab-pane-2" role="tab">Google Tag Manager</a>
    
                                <a class="menu-item" id="cookies-partner-menu-4" data-toggle="list" href="#" data-target="#cookies-partners-tabs .tab-pane-4" role="tab">Youtube</a>
    
    
                                <a class="menu-item" id="cookies-partner-menu-7" data-toggle="list" href="#" data-target="#cookies-partners-tabs .tab-pane-7" role="tab">Google Ads</a>
                                <a class="menu-item" id="cookies-partner-menu-8" data-toggle="list" href="#" data-target="#cookies-partners-tabs .tab-pane-8" role="tab">Pardot</a>
                            </div>
                        </div>
                        <div class="col-8 col-tabcontent">
                            <div class="tab-content" id="cookies-partners-tabs">
    
                                <div class="tab-pane fade show active tab-pane-2" data-code="gtm" role="tabpanel" aria-labelledby="cookies-partner-menu-2">
                                    <h4>Google TagManager</h4>
                                    <p class="pt-4">
                                        Nous utilisons le service Google TagManager. L’outil recueille des informations nous permettant de comprendre les interactions avec notre site Web, d’affiner cette expérience en améliorant le site mais aussi et surtout de mieux comprendre nos visiteurs.<br /><br />
                                        Vous pouvez obtenir davantage de précisions sur l’utilisation des cookies Google dans nos mentions légales. Par défaut, ces cookies sont activés sur notre site. Vous pouvez révoquer votre consentement à l’utilisation de cookies en désactivant le curseur ci-dessous.
                                    </p>
                                    <p class="pb-4">
                                        <a class="btn-toggler btn-cookie-accept" data-target="#cookies-partners-tabs .tab-pane-2 .btn-toggler" data-toggle="active"><span></span></a>
                                    </p>
                                </div>
    
                                <div class="tab-pane fade tab-pane-4" data-code="ytb" role="tabpanel" aria-labelledby="cookies-partner-menu-4">
                                    <h4>Youtube</h4>
                                    <p class="pt-4">
                                        Les cookies YouTube vous permettent de visualiser les vidéos partagées depuis la plateforme YouTube sur ce site. En visualisant ces vidéos, vous recevez des cookies YouTube. Nextformation ne contrôle pas l'archivage de ces cookies ni l'accès à ceux-ci. Vous devez lire les politiques de confidentialité de ces services afin de connaître les conditions dans lesquelles ces cookies sont utilisés. Si vous choisissez de les désactiver, vous ne pourrez plus visualiser les vidéos. Pour plus d'information visitez : <a href="//policies.google.com/privacy?hl=fr" target="_blank">Google Privacy & Terms</a>
                                    </p>
                                    <p class="pb-4">
                                        <a class="btn-toggler btn-cookie-accept" data-target="#cookies-partners-tabs .tab-pane-4 .btn-toggler" data-toggle="active"><span></span></a>
                                    </p>
                                </div>
    
    
                                <div class="tab-pane fade tab-pane-7" data-code="gad" role="tabpanel" aria-labelledby="cookies-partner-menu-7">
                                    <h4>Google Ads</h4>
                                    <p class="py-4">
                                        Le service Google Ads permet à Nextformation d’améliorer la pertinence des annonces publicitaires diffusées par Nextformation et d’effectuer des opérations de remarketing, qui consistent à présenter aux utilisateurs du site <a href="//www.nextformation.com" target="_blank">www.nextformation.com</a> des messages personnalisés lorsqu’ils visitent d'autres sites ou lorsqu’ils effectuent des recherches sur Google, en fonction du contenu qu’ils ont pu consulter sur ce site. Ces publicités se présentent sous la forme de bannières et/ou d’annonces texte.Ces informations sont conservées par Google Inc. Nextformation n’a pas la possibilité de vous identifier par le biais de ce cookie.<br /><br />
                                        Vous pouvez accéder aux réglages de Google Ads en vous rendant à la page : <a href="//www.google.com/settings/ads" target="_blank">https://www.google.com/settings/ads</a>
                                    </p>
                                    
                                </div>
                                <div class="tab-pane fade tab-pane-8" data-code="prdt" role="tabpanel" aria-labelledby="cookies-partner-menu-8">
                                    <h4>Pardot</h4>
                                    <p class="py-4">
                                        Nous utilisons l'outil PARDOT. L’outil recueille des informations nous permettant de comprendre les interactions avec notre site Web, d’affiner cette expérience en améliorant le site mais aussi et surtout de mieux comprendre nos visiteurs.<br />
                                        Vous pouvez obtenir davantage de précisions sur l’utilisation des cookies PARDOT dans nos mentions légales. Par défaut, ces cookies sont activés sur notre site. Vous pouvez révoquer votre consentement à l’utilisation de cookies en désactivant le curseur ci-dessous.
                                    </p>
                                    <p class="pb-4>">
                                        <a class="btn-toggler btn-cookie-accept" data-target="#cookies-partners-tabs .tab-pane-8 .btn-toggler" data-toggle="active"><span></span></a>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12 offset-md-4 col-md-8 pt-4 pt-md-0 pl-md-5 text-center text-md-left">
                            <a class="btn btn-secondary modalCookie" onclick="window.LCCookiesUI.lc.confirm(); return false;">Valider les paramètres</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

    </div>

<!-- Scripts -->

<script id="js-common" src="https://nextformation.com/app/themes/nextformation/dist/scripts/main_f7423051.js"></script>
<!-- /Scripts -->


</body>

</html>
